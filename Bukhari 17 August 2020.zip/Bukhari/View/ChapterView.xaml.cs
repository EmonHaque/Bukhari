﻿using System.Windows.Controls;

namespace Bukhari.View
{
    /// <summary>
    /// Interaction logic for ChapterView.xaml
    /// </summary>
    public partial class ChapterView : UserControl
    {
        public ChapterView()
        {
            InitializeComponent();
        }
    }
}
