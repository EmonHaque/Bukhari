﻿using Bukhari.Model;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Data;

namespace Bukhari.ViewModel
{
    public class ChapterVM : INotifyPropertyChanged
    {
        List<Chapter> Chapters { get; set; }
        public ICollectionView ChapterCollection { get; set; }

        Chapter selectedChapter;
        string chapterString, contentString;
        bool nameSort, numberSort, chapterSort;
        ICollectionView hadithCollection;

        public ICollectionView HadithCollection { get => hadithCollection; set { hadithCollection = value; OnPropertyChanged(); } }
        public Chapter SelectedChapter 
        { 
            get => selectedChapter; 
            set { 
                selectedChapter = value; 
                OnPropertyChanged();
                HadithCollection = CollectionViewSource.GetDefaultView(value.Hadith);
                HadithCollection.Filter = filterHadith;
            } 
        }
        public string ChapterString { get => chapterString; set { chapterString = value; OnPropertyChanged(); ChapterCollection.Refresh(); } }
        public string ContentString { get => contentString; set { contentString = value; OnPropertyChanged(); HadithCollection.Refresh(); } }
        public bool NameSort { get => nameSort; set { nameSort = value; OnPropertyChanged(); sort(value, "Name"); } }
        public bool NumberSort { get => numberSort; set { numberSort = value; OnPropertyChanged(); sort(value, "NoOfHadith"); } }
        public bool ChapterSort { get => chapterSort; set { chapterSort = value; OnPropertyChanged(); sort(value, "No"); } }

        public ChapterVM()
        {
            initializeChapters();
            SelectedChapter = Chapters.First();
            ChapterCollection = CollectionViewSource.GetDefaultView(Chapters);
            ChapterCollection.Filter = filterChapter;
        }

        void initializeChapters()
        {
            var chapters = new List<string>(MainVM.Hadith.Select(x => x.ChapterName).Distinct());
            Chapters = new List<Chapter>(chapters.Count);
            foreach (var chapter in chapters)
            {
                var first = MainVM.Hadith.First(x => x.ChapterName == chapter);
                var hadith = MainVM.Hadith.Where(x => x.ChapterNo == first.ChapterNo).ToList();
                Chapters.Add(new Chapter()
                {
                    Volume = first.Volume,
                    No = first.ChapterNo,
                    Name = first.ChapterName,
                    NoOfHadith = hadith.Count(),
                    Hadith = hadith
                });
            }
        }

        bool filterChapter(object o)
        {
            return string.IsNullOrWhiteSpace(ChapterString) ? true :
                (o as Chapter).Name.ToLower().Contains(ChapterString.ToLower());
        }

        bool filterHadith(object o)
        {
            return string.IsNullOrWhiteSpace(ContentString) ? true :
                (o as Data).Content.ToLower().Contains(ContentString.ToLower());
        }

        void sort(bool sort, string propertyName)
        {
            ChapterCollection.SortDescriptions.Clear();
            if (sort) ChapterCollection.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Ascending));
            else ChapterCollection.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Descending));
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
