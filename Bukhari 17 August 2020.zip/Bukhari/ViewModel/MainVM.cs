﻿using Bukhari.Model;
using Bukhari.View;
using Microsoft.Data.Sqlite;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Bukhari.ViewModel
{
    public class MainVM : INotifyPropertyChanged
    {
        public static ObservableCollection<Data> Hadith { get; set; } 
        public List<ViewInfo> Views { get; set; }


        ViewInfo selectedView;
        public ViewInfo SelectedView { get => selectedView; set { selectedView = value; OnPropertyChanged(); } }


        public MainVM()
        {
            Hadith = new ObservableCollection<Data>();
            getHadith();
            initializeViews();
        }

        void getHadith()
        {
            var db = new SqliteConnection(Constants.DBase);
            using var command = db.CreateCommand();
            command.CommandText = "SELECT * FROM Hadith";
            db.Open();
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                Hadith.Add(new Data()
                {
                    HadithNo = reader.GetInt32(0),                  
                    Volume = reader.GetInt32(1),
                    ChapterNo = reader.GetInt32(2),
                    ChapterName = reader.GetString(3),
                    OriginalBy = reader.GetString(4),
                    EditedBy = reader.GetString(5),
                    Content = reader.GetString(6)
                });
            }
            db.Close();
        }

        void initializeViews()
        {
            Views = new List<ViewInfo>()
            {
                new ViewInfo(){Name = "Summary", PathData = Constants.HomeIcon, View = new HomeView(), Description = "Summary"},
                new ViewInfo(){Name = "Chapters", PathData = Constants.ChapterIcon, View = new ChapterView(), Description = "Hadith by Chapter"},
                new ViewInfo(){Name = "Original", PathData = Constants.OriginalRabiIcon, View = new OriginalView(), Description = "Hadith by Narrator"},
                new ViewInfo(){Name = "Edit", PathData = Constants.EditedRabiIcon, View = new EditedView(), Description = "Hadith by Narrator, edit narrator's name"},
                new ViewInfo(){Name = "Narrators", PathData = Constants.NameMapIcon, View = new NameMapView(), Description = "See Narrators' original and edited name and edit"},
                new ViewInfo(){Name = "Search", PathData = Constants.ContentSearchIcon, View = new ContentSearchView(), Description = "Filter Hadith by content"}
            };
            SelectedView = Views.First();
        }


        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
        #endregion
    }

}
