﻿using Bukhari.Model;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Data;

namespace Bukhari.ViewModel
{
    public class NameMapVM : INotifyPropertyChanged
    {
        ObservableCollection<NameMap> names;
        public ICollectionView CollectionView { get; set; }

        string filterString;
        public string FilterString { get => filterString; set { filterString = value; OnPropertyChanged(); CollectionView.Refresh(); } }

        NameMap selectedRabi;
        public NameMap SelectedRabi { get => selectedRabi; set { selectedRabi = value; OnPropertyChanged(); } }


        public Command EditRabi { get; set; }
        public Command SaveRabi { get; set; }
        public Command Cancel { get; set; }

        public static event Action OnRabiEdited;

        public NameMapVM()
        {
            initializeNames();
            CollectionView = CollectionViewSource.GetDefaultView(names);
            CollectionView.Filter = filterRabi;

            EditRabi = new Command(editRabi, (o) => true);
            SaveRabi = new Command(saveRabi, (o) => true);
            Cancel = new Command(cancel, (o) => true);

            EditVM.OnRabiEdited4NameMap += UpdateNames;
        }

        void UpdateNames(EditedRabiArgs arg)
        {
            var edits = names.Where(x => x.ByEdited.Equals(arg.OldName));
            foreach (var edit in edits)
                edit.ByEdited = arg.NewName;
        }

        void cancel(object obj)
        {
            SelectedRabi.OnEdit = false;
        }

        void saveRabi(object o)
        {
            var editedName = o as string;
            if (!string.IsNullOrWhiteSpace(editedName))
            {
                var db = new SqliteConnection(Constants.DBase);
                using var command = db.CreateCommand();
                command.CommandText = "UPDATE Hadith SET ByEdited = @EditedName WHERE ChapterNo = @ChapterNo AND No = @HadithNo";
                command.Parameters.AddWithValue("@EditedName", editedName);
                command.Parameters.AddWithValue("@ChapterNo", SelectedRabi.ChapterNo);
                command.Parameters.AddWithValue("@HadithNo", SelectedRabi.HadithNo);
                db.Open();
                command.ExecuteNonQuery();
                db.Close();

                SelectedRabi.OnEdit = false;
                SelectedRabi.ByEdited = editedName;

                var edited = MainVM.Hadith.First(x => x.ChapterNo == SelectedRabi.ChapterNo && x.HadithNo == SelectedRabi.HadithNo);
                MainVM.Hadith[MainVM.Hadith.IndexOf(edited)].EditedBy = editedName;

                OnRabiEdited?.Invoke();
            }
        }

        void editRabi(object o)
        {
            SelectedRabi = o as NameMap;
            SelectedRabi.OnEdit = !SelectedRabi.OnEdit;
        }

        bool filterRabi(object o)
        {
            return string.IsNullOrWhiteSpace(FilterString) ? true :
                (o as NameMap).ByOriginal.ToLower().Contains(FilterString.ToLower());
        }

        void initializeNames()
        {
            var collection = MainVM.Hadith.Select(x => new NameMap()
            {
                Volume = x.Volume,
                ChapterNo = x.ChapterNo,
                ChapterName = x.ChapterName,
                HadithNo = x.HadithNo,
                ByOriginal = x.OriginalBy,
                ByEdited = x.EditedBy
            });
            names = new ObservableCollection<NameMap>(collection);

        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
