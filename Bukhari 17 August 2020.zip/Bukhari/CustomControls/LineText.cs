﻿using System.Windows;
using System.Windows.Controls;

namespace Bukhari.CustomControls
{
    public class LineText : TextBox
    {
        static LineText()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(LineText), new FrameworkPropertyMetadata(typeof(LineText)));
        }
    }
}
