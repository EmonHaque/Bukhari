﻿namespace Bukhari.Model
{
    public class GrandSummary
    {
        public int ChapterOrNarratorCount { get; set; }
        public int HadithCount { get; set; }
    }
}
