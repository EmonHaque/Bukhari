﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Bukhari.Model
{
    public class Data : INotifyPropertyChanged
    {
        string editedBy;

        public int Volume { get; set; }
        public int ChapterNo { get; set; }
        public int HadithNo { get; set; }
        public string ChapterName { get; set; }
        public string OriginalBy { get; set; }
        public string Content { get; set; }
        public string EditedBy { get => editedBy; set { editedBy = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
