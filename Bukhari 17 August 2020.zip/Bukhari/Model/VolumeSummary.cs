﻿namespace Bukhari.Model
{
    public class VolumeSummary
    {
        public int No { get; set; }
        public int Chapters { get; set; }
        public int Hadith { get; set; }
    }
}
