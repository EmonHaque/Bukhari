﻿using System.Collections.Generic;

namespace Bukhari.Model
{
    public class Chapter
    {
        public int Volume { get; set; }
        public int No { get; set; }
        public string Name { get; set; }
        public int NoOfHadith { get; set; }
        public List<Data> Hadith { get; set; }
    }
}
