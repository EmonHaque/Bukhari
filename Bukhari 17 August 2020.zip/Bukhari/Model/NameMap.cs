﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Bukhari.Model
{
    public class NameMap : INotifyPropertyChanged
    {
        public int Volume { get; set; }
        public int ChapterNo { get; set; }
        public string ChapterName { get; set; }
        public int HadithNo { get; set; }
        public string ByOriginal { get; set; }

        string byEdited;
        public string ByEdited { get => byEdited; set { byEdited = value; OnPropertyChanged(); } }

        bool onEdit;
        public bool OnEdit { get => onEdit; set { onEdit = value; OnPropertyChanged(); } }


        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
