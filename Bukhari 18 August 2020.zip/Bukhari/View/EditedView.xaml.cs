﻿using System.Windows.Controls;

namespace Bukhari.View
{
    /// <summary>
    /// Interaction logic for EditedView.xaml
    /// </summary>
    public partial class EditedView : UserControl
    {
        public EditedView()
        {
            InitializeComponent();
        }
    }
}
