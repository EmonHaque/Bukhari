﻿using Bukhari.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Data;

namespace Bukhari.ViewModel
{

    public class OriginalVM : INotifyPropertyChanged
    {
        List<Rabi> rabis { get; set; }
        public ICollectionView RabiCollection { get; set; }

        Rabi selectedRabi;
        string narratorString, contentString;
        bool nameSort, numberSort;

        ICollectionView hadithCollection;

        public ICollectionView HadithCollection { get => hadithCollection; set { hadithCollection = value; OnPropertyChanged(); } }
        public Rabi SelectedRabi
        {
            get => selectedRabi;
            set
            {
                selectedRabi = value;
                OnPropertyChanged();
                HadithCollection = CollectionViewSource.GetDefaultView(value.Hadith);
                HadithCollection.Filter = filterHadith;
            }
        }
        public string NarratorString { get => narratorString; set { narratorString = value; OnPropertyChanged(); RabiCollection.Refresh(); } }
        public string ContentString { get => contentString; set { contentString = value; OnPropertyChanged(); HadithCollection.Refresh(); } }
        public bool NameSort { get => nameSort; set { nameSort = value; OnPropertyChanged(); sortRabis(value, "Name"); } }
        public bool NumberSort { get => numberSort; set { numberSort = value; OnPropertyChanged(); sortRabis(value, "NoOfHadith"); } }

        public static event Action<IEnumerable<Rabi>> OnRabiInitialized;

        public OriginalVM()
        {
            initializeRabis();
            SelectedRabi = rabis.First();
            RabiCollection = CollectionViewSource.GetDefaultView(rabis);
            RabiCollection.Filter = filterRabi;
        }

        void initializeRabis()
        {
            var rabis = new List<string>(MainVM.Hadith.Select(x => x.OriginalBy).Distinct());
            this.rabis = new List<Rabi>(rabis.Count());
            foreach (var rabi in rabis)
            {
                var hadith = MainVM.Hadith.Where(x => x.OriginalBy == rabi).ToList();
                this.rabis.Add(new Rabi()
                {
                    Name = rabi,
                    NoOfHadith = hadith.Count(),
                    Hadith = hadith
                });
            }
            OnRabiInitialized?.Invoke(this.rabis);
        }

        bool filterRabi(object o)
        {
            return string.IsNullOrWhiteSpace(NarratorString) ? true :
                (o as Rabi).Name.ToLower().Contains(NarratorString.ToLower());
        }

        bool filterHadith(object o)
        {
            return string.IsNullOrWhiteSpace(ContentString) ? true :
                (o as Data).Content.ToLower().Contains(ContentString.ToLower());
        }

        void sortRabis(bool sort, string propertyName)
        {
            RabiCollection.SortDescriptions.Clear();
            if (sort) RabiCollection.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Ascending));
            else RabiCollection.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Descending));
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
