﻿using Bukhari.Model;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Data;

namespace Bukhari.ViewModel
{
    public class EditVM : INotifyPropertyChanged
    {
        string name;
        ObservableCollection<Rabi> rabis { get; set; }
        public ICollectionView RabiCollection { get; set; }

        Rabi selectedRabi;
        string narratorString, contentString;
        bool nameSort, numberSort;
        ICollectionView hadithCollection;

        public ICollectionView HadithCollection { get => hadithCollection; set { hadithCollection = value; OnPropertyChanged(); } }

        public Rabi SelectedRabi 
        { 
            get => selectedRabi; 
            set 
            { 
                selectedRabi = value; 
                OnPropertyChanged();
                HadithCollection = CollectionViewSource.GetDefaultView(value.Hadith);
                HadithCollection.Filter = filterHadith;
            } 
        }       

        public string NarratorString { get => narratorString; set { narratorString = value; OnPropertyChanged(); RabiCollection.Refresh(); } }
        public string ContentString { get => contentString; set { contentString = value; OnPropertyChanged(); HadithCollection.Refresh(); } }
        public bool NameSort { get => nameSort; set { nameSort = value; OnPropertyChanged(); sortRabis(value, "Name"); } }
        public bool NumberSort { get => numberSort; set { numberSort = value; OnPropertyChanged(); sortRabis(value, "NoOfHadith"); }}

        public static event Action<IEnumerable<Rabi>> OnRabiInitialized;
        public static event Action<IEnumerable<Rabi>> OnRabiEdited;
        public static event Action<EditedRabiArgs> OnRabiEdited4NameMap;

        public Command EditRabi { get; set; }
        public Command SaveRabi { get; set; }
        public Command Cancel { get; set; }

        public EditVM()
        {
            initializeRabis();
            SelectedRabi = rabis.First();
            RabiCollection = CollectionViewSource.GetDefaultView(rabis);
            RabiCollection.Filter = filterRabi;
            EditRabi = new Command(editRabi, (o) => true);
            SaveRabi = new Command(saveRabi, (o) => true);
            Cancel = new Command(cancel, (o) => true);

            NameMapVM.OnRabiEdited += UpdateRabis;
        }

        void UpdateRabis()
        {
            var rabis = new List<string>(MainVM.Hadith.Select(x => x.EditedBy).Distinct());
            this.rabis.Clear();
            foreach (var rabi in rabis)
            {
                var hadith = MainVM.Hadith.Where(x => string.Equals(x.EditedBy, rabi)).ToList();
                this.rabis.Add(new Rabi()
                {
                    Name = rabi,
                    NoOfHadith = hadith.Count(),
                    Hadith = hadith
                });
            }
            OnRabiEdited?.Invoke(this.rabis);
        }

        void cancel(object obj)
        {
            SelectedRabi.OnEdit = false;
        }

        void saveRabi(object o)
        {        
            var editedName = o as string;
            if (!string.IsNullOrWhiteSpace(editedName))
            {
                var db = new SqliteConnection(Constants.DBase);
                using var command = db.CreateCommand();
                command.CommandText = "UPDATE Hadith SET ByEdited = @EditedName WHERE ByEdited = @Name";
                command.Parameters.AddWithValue("@EditedName", editedName);
                command.Parameters.AddWithValue("@Name", name);
                db.Open();
                command.ExecuteNonQuery();
                db.Close();

                SelectedRabi.OnEdit = false;
                var matched = rabis.Where(x => x.Name == editedName).FirstOrDefault();
                if(matched != null)
                {
                    matched.NoOfHadith += SelectedRabi.NoOfHadith;
                    matched.Hadith.AddRange(SelectedRabi.Hadith);
                    matched.Hadith = matched.Hadith.OrderBy(x => x.Volume).ThenBy(x => x.ChapterNo).ThenBy(x => x.HadithNo).ToList();
                    rabis.Remove(SelectedRabi);
                    SelectedRabi = matched;
                }
                else SelectedRabi.Name = editedName;                
                OnRabiEdited?.Invoke(rabis);
                OnRabiEdited4NameMap?.Invoke(new EditedRabiArgs() { OldName = name, NewName = editedName });
            }            
        }

        void editRabi(object o)
        {
            SelectedRabi = o as Rabi;
            name = SelectedRabi.Name;
            SelectedRabi.OnEdit = !SelectedRabi.OnEdit;
        }

        bool filterRabi(object o)
        {
            return string.IsNullOrWhiteSpace(NarratorString) ? true :
                (o as Rabi).Name.ToLower().Contains(NarratorString.ToLower());
        }

        bool filterHadith(object o)
        {
            return string.IsNullOrWhiteSpace(ContentString) ? true :
                (o as Data).Content.ToLower().Contains(ContentString.ToLower());
        }

        void sortRabis(bool sort, string propertyName)
        {
            RabiCollection.SortDescriptions.Clear();
            if (sort) RabiCollection.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Ascending));
            else RabiCollection.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Descending));
        }

        void initializeRabis()
        {
            var rabis = new List<string>(MainVM.Hadith.Select(x => x.EditedBy).Distinct());
            this.rabis = new ObservableCollection<Rabi>();
            foreach (var rabi in rabis)
            {
                var hadith = MainVM.Hadith.Where(x => string.Equals( x.EditedBy, rabi)).ToList();
                this.rabis.Add(new Rabi()
                {
                    Name = rabi,
                    NoOfHadith = hadith.Count(),
                    Hadith = hadith
                });
            }
            OnRabiInitialized?.Invoke(this.rabis);
        }
         
        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }
}
