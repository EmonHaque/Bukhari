﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace Bukhari.CustomControls
{
    public class HighlightBlock : TextBlock
    {
        //static HighlightBlock()
        //{
        //    DefaultStyleKeyProperty.OverrideMetadata(typeof(HighlightBlock), new FrameworkPropertyMetadata(typeof(HighlightBlock)));
        //}

        public new string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
        public new static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(HighlightBlock), new PropertyMetadata(string.Empty, new PropertyChangedCallback(highlight)));


        public string Phrase
        {
            get { return (string)GetValue(PhraseProperty); }
            set { SetValue(PhraseProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Phrase.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PhraseProperty =
            DependencyProperty.Register("Phrase", typeof(string), typeof(HighlightBlock), new FrameworkPropertyMetadata(string.Empty, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, new PropertyChangedCallback(highlight)));

        static void highlight(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var block = d as HighlightBlock;
            var text = block.Text;
            var phrase = block.Phrase;
            
            block.Inlines.Clear();
            if (string.IsNullOrWhiteSpace(phrase)) block.Inlines.Add(text);
            else
            {
                int index = text.IndexOf(phrase, StringComparison.OrdinalIgnoreCase);
                if (index < 0) block.Inlines.Add(text);
                else
                {
                    int startIndex = 0;
                    for (int i = text.IndexOf(phrase, StringComparison.OrdinalIgnoreCase); i > -1; i = text.IndexOf(phrase, i + 1, StringComparison.OrdinalIgnoreCase))
                    {
                        block.Inlines.Add(text.Substring(startIndex, i - startIndex));
                        block.Inlines.Add(new Run(text.Substring(i, phrase.Length)) { Background = Brushes.LightBlue });
                        startIndex = i + phrase.Length;
                    }
                    if (startIndex < text.Length) block.Inlines.Add(text.Substring(startIndex));
                }
            }
        }
    }
}
