﻿using System.Windows;
using System.Windows.Controls.Primitives;

namespace Bukhari.CustomControls
{
    public class Toggle : ToggleButton
    {
        static Toggle()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Toggle), new FrameworkPropertyMetadata(typeof(Toggle)));
        }


        public string CheckedPath
        {
            get { return (string)GetValue(CheckedPathProperty); }
            set { SetValue(CheckedPathProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CheckedPath.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CheckedPathProperty =
            DependencyProperty.Register("CheckedPath", typeof(string), typeof(Toggle), new PropertyMetadata(null));


        public string UncheckedPath
        {
            get { return (string)GetValue(UncheckedPathProperty); }
            set { SetValue(UncheckedPathProperty, value); }
        }

        // Using a DependencyProperty as the backing store for UncheckedPath.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty UncheckedPathProperty =
            DependencyProperty.Register("UncheckedPath", typeof(string), typeof(Toggle), new PropertyMetadata(null));

    }
}
