﻿using System.Windows.Controls;

namespace Bukhari.Model
{
    public class ViewInfo
    {
        public string Name { get; set; }
        public string PathData { get; set; }
        public UserControl View { get; set; }
        public string Description { get; set; }
    }
}
