﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Bukhari.Model
{
    public class Rabi : INotifyPropertyChanged
    {
        string name;
        int noOfHadith;
        List<Data> hadith;
        bool onEdit;

        public string Name { get => name; set { name = value; OnPropertyChanged(); } }      
        public int NoOfHadith { get => noOfHadith; set { noOfHadith = value; OnPropertyChanged(); } }        
        public List<Data> Hadith { get => hadith; set { hadith = value; OnPropertyChanged(); } }      
        public bool OnEdit { get => onEdit; set { onEdit = value; OnPropertyChanged(); } }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
