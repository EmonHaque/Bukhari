﻿namespace Bukhari.Model
{
    public class EditedRabiArgs
    {
        public string OldName { get; set; }
        public string NewName { get; set; }
    }
}
