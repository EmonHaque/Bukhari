﻿namespace Bukhari.Model
{
    public class NarratorSummary
    {
        public int Range { get; set; }
        public int Narrators { get; set; }
        public int Hadith { get; set; }
    }
}
