﻿using Bukhari.Model;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Data;

namespace Bukhari.ViewModel
{
    public class ContentSearchVM : INotifyPropertyChanged
    {
        public ICollectionView CollectionView { get; set; }

        string filterString;
        public string FilterString { get => filterString; set { filterString = value; OnPropertyChanged(); CollectionView.Refresh(); } }

        public ContentSearchVM()
        {
            CollectionView = CollectionViewSource.GetDefaultView(MainVM.Hadith);
            CollectionView.Filter = filterContent;
        }

        bool filterContent(object o)
        {
            return string.IsNullOrWhiteSpace(FilterString) ? true :
                (o as Data).Content.ToLower().Contains(FilterString.ToLower());
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
