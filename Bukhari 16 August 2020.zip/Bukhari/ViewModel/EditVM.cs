﻿using Bukhari.Model;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Data;

namespace Bukhari.ViewModel
{
    public class EditVM : INotifyPropertyChanged
    {
        string name;
        ObservableCollection<Rabi> Rabis { get; set; }
        public ICollectionView CollectionView { get; set; }

        Rabi selectedRabi;
        string filterString;
        bool nameSort, numberSort;

        public Rabi SelectedRabi { get => selectedRabi; set { selectedRabi = value; OnPropertyChanged(); } }      
        public string FilterString { get => filterString; set { filterString = value; OnPropertyChanged(); CollectionView.Refresh(); } }     
        public bool NameSort { get => nameSort; set { nameSort = value; OnPropertyChanged(); sortRabis(value, "Name"); } }
        public bool NumberSort { get => numberSort; set { numberSort = value; OnPropertyChanged(); sortRabis(value, "NoOfHadith"); }}

        public static event Action<IEnumerable<Rabi>> OnRabiInitialized;
        public static event Action<IEnumerable<Rabi>> OnRabiEdited;
        public static event Action<EditedRabiArgs> OnRabiEdited4NameMap;

        public Command EditRabi { get; set; }
        public Command SaveRabi { get; set; }
        public Command Cancel { get; set; }

        public EditVM()
        {
            initializeRabis();
            SelectedRabi = Rabis.First();
            CollectionView = CollectionViewSource.GetDefaultView(Rabis);
            CollectionView.Filter = filterRabi;
            EditRabi = new Command(editRabi, (o) => true);
            SaveRabi = new Command(saveRabi, (o) => true);
            Cancel = new Command(cancel, (o) => true);

            NameMapVM.OnRabiEdited += UpdateRabis;
        }

        void UpdateRabis()
        {
            var rabis = new List<string>(MainVM.Hadith.Select(x => x.EditedBy).Distinct());
            Rabis.Clear();
            foreach (var rabi in rabis)
            {
                var hadith = MainVM.Hadith.Where(x => string.Equals(x.EditedBy, rabi)).ToList();
                Rabis.Add(new Rabi()
                {
                    Name = rabi,
                    NoOfHadith = hadith.Count(),
                    Hadith = hadith
                });
            }
            OnRabiEdited?.Invoke(Rabis);
        }

        void cancel(object obj)
        {
            SelectedRabi.OnEdit = false;
        }

        void saveRabi(object o)
        {        
            var editedName = o as string;
            if (!string.IsNullOrWhiteSpace(editedName))
            {
                var db = new SqliteConnection(Constants.DBase);
                using var command = db.CreateCommand();
                command.CommandText = "UPDATE Hadith SET ByEdited = @EditedName WHERE ByEdited = @Name";
                command.Parameters.AddWithValue("@EditedName", editedName);
                command.Parameters.AddWithValue("@Name", name);
                db.Open();
                command.ExecuteNonQuery();
                db.Close();

                SelectedRabi.OnEdit = false;
                var matched = Rabis.Where(x => x.Name == editedName).FirstOrDefault();
                if(matched != null)
                {
                    matched.NoOfHadith += SelectedRabi.NoOfHadith;
                    matched.Hadith.AddRange(SelectedRabi.Hadith);
                    matched.Hadith = matched.Hadith.OrderBy(x => x.Volume).ThenBy(x => x.ChapterNo).ThenBy(x => x.HadithNo).ToList();
                    Rabis.Remove(SelectedRabi);
                    SelectedRabi = matched;
                }
                else SelectedRabi.Name = editedName;                
                OnRabiEdited?.Invoke(Rabis);
                OnRabiEdited4NameMap?.Invoke(new EditedRabiArgs() { OldName = name, NewName = editedName });
            }            
        }

        void editRabi(object o)
        {
            SelectedRabi = o as Rabi;
            name = SelectedRabi.Name;
            SelectedRabi.OnEdit = !SelectedRabi.OnEdit;
        }

        bool filterRabi(object o)
        {
            return string.IsNullOrWhiteSpace(FilterString) ? true :
                (o as Rabi).Name.ToLower().Contains(FilterString.ToLower());
        }

        void sortRabis(bool sort, string propertyName)
        {
            CollectionView.SortDescriptions.Clear();
            if (sort) CollectionView.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Ascending));
            else CollectionView.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Descending));
        }

        void initializeRabis()
        {
            var rabis = new List<string>(MainVM.Hadith.Select(x => x.EditedBy).Distinct());
            Rabis = new ObservableCollection<Rabi>();
            foreach (var rabi in rabis)
            {
                var hadith = MainVM.Hadith.Where(x => string.Equals( x.EditedBy, rabi)).ToList();
                Rabis.Add(new Rabi()
                {
                    Name = rabi,
                    NoOfHadith = hadith.Count(),
                    Hadith = hadith
                });
            }
            OnRabiInitialized?.Invoke(Rabis);
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
