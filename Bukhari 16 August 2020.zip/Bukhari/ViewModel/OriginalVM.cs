﻿using Bukhari.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Data;

namespace Bukhari.ViewModel
{

    public class OriginalVM : INotifyPropertyChanged
    {
        List<Rabi> Rabis { get; set; }
        public ICollectionView CollectionView { get; set; }

        Rabi selectedRabi;
        string filterString;
        bool nameSort, numberSort;

        public Rabi SelectedRabi { get => selectedRabi; set { selectedRabi = value; OnPropertyChanged(); } }
        public string FilterString { get => filterString; set { filterString = value; OnPropertyChanged(); CollectionView.Refresh(); } }
        public bool NameSort { get => nameSort; set { nameSort = value; OnPropertyChanged(); sortRabis(value, "Name"); } }
        public bool NumberSort { get => numberSort; set { numberSort = value; OnPropertyChanged(); sortRabis(value, "NoOfHadith"); } }

        public static event Action<IEnumerable<Rabi>> OnRabiInitialized;

        public OriginalVM()
        {
            initializeRabis();
            SelectedRabi = Rabis.First();
            CollectionView = CollectionViewSource.GetDefaultView(Rabis);
            CollectionView.Filter = filterRabi;
        }

        void initializeRabis()
        {
            var rabis = new List<string>(MainVM.Hadith.Select(x => x.OriginalBy).Distinct());
            Rabis = new List<Rabi>(rabis.Count());
            foreach (var rabi in rabis)
            {
                var hadith = MainVM.Hadith.Where(x => x.OriginalBy == rabi).ToList();
                Rabis.Add(new Rabi()
                {
                    Name = rabi,
                    NoOfHadith = hadith.Count(),
                    Hadith = hadith
                });
            }
            OnRabiInitialized?.Invoke(Rabis);
        }

        bool filterRabi(object o)
        {
            return string.IsNullOrWhiteSpace(FilterString) ? true :
                (o as Rabi).Name.ToLower().Contains(FilterString.ToLower());
        }

        void sortRabis(bool sort, string propertyName)
        {
            CollectionView.SortDescriptions.Clear();
            if (sort) CollectionView.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Ascending));
            else CollectionView.SortDescriptions.Add(new SortDescription(propertyName, ListSortDirection.Descending));
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
