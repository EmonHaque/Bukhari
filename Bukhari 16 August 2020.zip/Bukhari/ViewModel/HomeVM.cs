﻿using Bukhari.Model;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Bukhari.ViewModel
{
    public class HomeVM : INotifyPropertyChanged
    {
        public List<VolumeSummary> VolumeSummary { get; set; }
        public ObservableCollection<NarratorSummary> OriginalSummary { get; set; }
        public ObservableCollection<NarratorSummary> EditedSummary { get; set; }
        public GrandSummary Volume { get; set; }

        GrandSummary edited, original;
        public GrandSummary Edited { get => edited; set { edited = value; OnPropertyChanged(); } }
        public GrandSummary Original { get => original; set { original = value; OnPropertyChanged(); } }


        public HomeVM()
        {
            OriginalSummary = new ObservableCollection<NarratorSummary>();
            EditedSummary = new ObservableCollection<NarratorSummary>();
            subscribe();
            summarizeByVolume();
        }

        void subscribe()
        {
            OriginalVM.OnRabiInitialized += summarizeByOriginalRabis;
            EditVM.OnRabiInitialized += summarizeByEditedRabis;
            EditVM.OnRabiEdited += UpdateEditedSummary;
        }

        void UpdateEditedSummary(IEnumerable<Rabi> rabis)
        {
            EditedSummary.Clear();
            summarizeRange(rabis, EditedSummary);
            Edited = new GrandSummary()
            {
                ChapterOrNarratorCount = EditedSummary.Sum(x => x.Narrators),
                HadithCount = EditedSummary.Sum(x => x.Hadith)
            };
        }

        void summarizeByVolume()
        {
            VolumeSummary = new List<VolumeSummary>();
            var volumes = MainVM.Hadith.Select(x => x.Volume).Distinct();
            foreach (var volume in volumes)
            {
                var hadith = MainVM.Hadith.Where(x => x.Volume == volume).ToList();
                VolumeSummary.Add(new Model.VolumeSummary()
                {
                    No = volume,
                    Chapters = hadith.Select(x => x.ChapterNo).Distinct().Count(),
                    Hadith = hadith.Count
                });
            }
            Volume = new GrandSummary()
            {
                ChapterOrNarratorCount = VolumeSummary.Sum(x => x.Chapters),
                HadithCount = VolumeSummary.Sum(x => x.Hadith)
            };
        }

        void summarizeByOriginalRabis(IEnumerable<Rabi> rabis)
        {
            OriginalVM.OnRabiInitialized -= summarizeByOriginalRabis;
            summarizeRange(rabis, OriginalSummary);
            Original = new GrandSummary()
            {
                ChapterOrNarratorCount = OriginalSummary.Sum(x => x.Narrators),
                HadithCount = OriginalSummary.Sum(x => x.Hadith)
            };
        }       

        void summarizeByEditedRabis(IEnumerable<Rabi> rabis)
        {
            EditVM.OnRabiInitialized -= summarizeByEditedRabis;
            summarizeRange(rabis, EditedSummary);
            Edited = new GrandSummary()
            {
                ChapterOrNarratorCount = EditedSummary.Sum(x => x.Narrators),
                HadithCount = EditedSummary.Sum(x => x.Hadith)
            };
        }

        void createRange(ObservableCollection<NarratorSummary> list)
        {
            list.Add(new NarratorSummary() { Range = 100 });
            list.Add(new NarratorSummary() { Range = 50 });
            list.Add(new NarratorSummary() { Range = 25 });
            list.Add(new NarratorSummary() { Range = 10 });
            list.Add(new NarratorSummary() { Range = 5 });
            list.Add(new NarratorSummary() { Range = 4 });
            list.Add(new NarratorSummary() { Range = 3 });
            list.Add(new NarratorSummary() { Range = 2 });
            list.Add(new NarratorSummary() { Range = 1 });
        }

        void summarizeRange(IEnumerable<Rabi> rabis, ObservableCollection<NarratorSummary> list)
        {
            createRange(list);

            for (int i = 0; i < 9; i++)
            {
                IEnumerable<Rabi> inRange;

                if (i == 0) inRange = rabis.Where(x => x.NoOfHadith >= 100);                
                else if (i > 3)
                {
                    inRange = i == 4 ? 
                        rabis.Where(x => x.NoOfHadith < list[i - 1].Range && x.NoOfHadith >= list[i].Range) : 
                        rabis.Where(x => x.NoOfHadith == list[i].Range);
                }
                else inRange = rabis.Where(x => x.NoOfHadith < list[i - 1].Range && x.NoOfHadith >= list[i].Range);

                list[i].Hadith = inRange.Sum(x => x.NoOfHadith);
                list[i].Narrators = inRange.Count();
            }
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
