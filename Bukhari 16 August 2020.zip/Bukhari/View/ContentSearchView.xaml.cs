﻿using System.Windows.Controls;

namespace Bukhari.View
{
    /// <summary>
    /// Interaction logic for ContentSearchView.xaml
    /// </summary>
    public partial class ContentSearchView : UserControl
    {
        public ContentSearchView()
        {
            InitializeComponent();
        }
    }
}
