﻿using System.Windows.Controls;

namespace Bukhari.View
{
    /// <summary>
    /// Interaction logic for NameMapView.xaml
    /// </summary>
    public partial class NameMapView : UserControl
    {
        public NameMapView()
        {
            InitializeComponent();
        }
    }
}
