﻿using System.Windows.Controls;

namespace Bukhari.View
{
    /// <summary>
    /// Interaction logic for OriginalView.xaml
    /// </summary>
    public partial class OriginalView : UserControl
    {
        public OriginalView()
        {
            InitializeComponent();
        }
    }
}
